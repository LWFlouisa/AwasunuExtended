###############################################################################
#                  Three Way Conditions [ Nombres Et Kosan ]                  #
###############################################################################
# Note that this shouldn't be confused for nombre and kosan. These are used   #
# for making discrete and continuous decision trees. Standard Nombre and      #
# Kosan is used for ternary conditions.                                       #
###############################################################################
define_method :cette_nombre do |condition|
  if condition
    if yield and yield.is_a?(Integer)      
      return true
    else
      return "Error: Sore_float is not a Float."
    end
  end
  
  false
end

define_method :maisette_nombre do |already_done, condition|
  return true if already_done
  
  if condition
    if yield and yield.is_a?(Integer)      
      return true
    else
      return "Error: Shikashi_float is not a Float."
    end
  end
end

define_method :sinon_nombre do |already_done|
  value = yield unless already_done

  if value and value.is_a?(Integer)
    return true
  else
    return "Error: Shikashi_float is not a Float."
  end
  
  unless already_done
    otherwise = already_done
      
    if defined?(otherwise)
      puts otherwise
    end
  else
    puts "Otherwise is not defined."
  end
end

## That time
define_method :sore_kosan do |condition|
  if condition
    if yield and yield.is_a?(Float)
      return true
    else
      return "Error: Sore_float is not a Float."
    end
  end
  
  false
end

define_method :shikashi_kosan do |already_done, condition|
  return true if already_done
  
  if condition
    if yield and yield.is_a?(Float)
      return true
    else
      return "Error: Shikashi_float is not a Float."
    end
  end
end

define_method :matawa_kosan do |already_done|
  value = yield unless already_done

  if value and value.is_a?(Float)
    return true
  else
    return "Error: Shikashi_float is not a Float."
  end
  
  unless already_done
    otherwise = already_done
      
    if defined?(otherwise)
      puts otherwise
    
      #puts "#{$otherwise_not[0]} is 'THAT'"
      #puts "#{$otherwise_not[1]} is 'WHAT'"
    end
  else
    puts "Otherwise is not defined."
  end
end
