## Basic qualifiers
define_method :cette do |noun, color|
  "Cette #{noun} est #{color}."
end

define_method :maisette do |noun, color|
  "Mais cette #{noun} est #{color}."
end

define_method :sinon do |noun, non_color1, non_color2, valid_color|
  "Sinon cette #{noun} n'est #{non_color1} ou #{non_color2}, mais est #{valid_color}."
end

define_method :necette do |noun, color|
  "Cette #{noun} n'est #{color}."
end

define_method :nemaisette do |noun, color|
  "Mais cette #{noun} n'est #{color}."
end

define_method :nesinon do |noun, non_color1, non_color2, valid_color|
  "#{nouns.upcase} est plus #{non_colour1} et moins #{non_color2}."
end

## Contrasting
define_method :contrast do |specify_cette, specify_maisette, specify_sinon|
  "#{specify_cette} #{specify_maisette} #{specify_sinon}"
end

define_method :negative_contrast do |not_cette, not_maisette, not_sinon|
  "#{specify_cette} #{specify_maisette} #{specify_sinon}"
end

define_method :cette_nombre do |base_number, max_value|
  if base_number.is_a?(Integer)
    if base_number > max_value
      cette(base_number, "plus #{max_value}")
    else
      necette(base_number, "plus #{max_value}")
    end
  else
    "Error: Cette nombre n'est un Integer."
  end
end

define_method :maisette_nombre do |base_number, min_value|
  if base_number.is_a?(Integer)
    if base_number < min_value
      maisette(base_number, "moins #{min_value}")
    else
      nemaisette(base_number, "moins #{min_value}")
    end
  else
    "Error: Mais cette nombre n'est un Integer."
  end
end

define_method :sinon_nombre do |base_number, max_value, min_value|
  if base_number.is_a?(Integer)
    if base_number < max_value and base_number > min_value
      sinon(base_number, max_value, min_value, base_number)
    else
      cette(base_number, "plus #{max_value}")
      maisette(base_number, "moins #{max_value}")
    end
  else
    "Error: Sinon cette nombre n'est un Integer."
  end
end
